package com.example.taoautorecorder

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Bundle
import android.os.Build
import android.os.SystemClock
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.CopyOnWriteArrayList
import kotlin.math.abs

private const val PREFS = "tao_auto_recorder"
private const val KEY_FLOW = "last_flow"
private const val TAOBAO_PACKAGE = "com.taobao.taobao"
private const val TAP_DURATION = 70L

/** A serializable user action. */
data class RecordedStep(
    val type: String,
    val timestamp: Long,
    val waitMs: Long,
    val packageName: String?,
    val className: String?,
    val viewId: String?,
    val text: String?,
    val contentDescription: String?,
    val x: Float? = null,
    val y: Float? = null,
    val x2: Float? = null,
    val y2: Float? = null,
    val durationMs: Long? = null,
    val scrollDx: Int? = null,
    val scrollDy: Int? = null,
    val sensitive: Boolean = false
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("type", type)
        put("timestamp", timestamp)
        put("waitMs", waitMs)
        putOpt("packageName", packageName)
        putOpt("className", className)
        putOpt("viewId", viewId)
        putOpt("text", text)
        putOpt("contentDescription", contentDescription)
        putOpt("x", x)
        putOpt("y", y)
        putOpt("x2", x2)
        putOpt("y2", y2)
        putOpt("durationMs", durationMs)
        putOpt("scrollDx", scrollDx)
        putOpt("scrollDy", scrollDy)
        put("sensitive", sensitive)
    }

    companion object {
        fun fromJson(o: JSONObject) = RecordedStep(
            o.optString("type").ifBlank { "UNKNOWN" },
            o.optLong("timestamp"),
            o.optLong("waitMs", 300),
            o.optString("packageName").takeIf { it.isNotBlank() },
            o.optString("className").takeIf { it.isNotBlank() },
            o.optString("viewId").takeIf { it.isNotBlank() },
            o.optString("text").takeIf { it.isNotBlank() },
            o.optString("contentDescription").takeIf { it.isNotBlank() },
            if (o.has("x")) o.optDouble("x").toFloat() else null,
            if (o.has("y")) o.optDouble("y").toFloat() else null,
            if (o.has("x2")) o.optDouble("x2").toFloat() else null,
            if (o.has("y2")) o.optDouble("y2").toFloat() else null,
            if (o.has("durationMs")) o.optLong("durationMs") else null,
            if (o.has("scrollDx")) o.optInt("scrollDx") else null,
            if (o.has("scrollDy")) o.optInt("scrollDy") else null,
            o.optBoolean("sensitive", false)
        )
    }
}

class AutomationAccessibilityService : AccessibilityService() {
    @Volatile var isRecording: Boolean = false
        private set
    @Volatile var isReplaying: Boolean = false
        private set

    private var lastActionAt = 0L
    private var lastTextAt = 0L
    private var lastTextKey = ""

    val recordedSteps: MutableList<RecordedStep> = CopyOnWriteArrayList()

    companion object {
        @Volatile var instance: AutomationAccessibilityService? = null
            private set

        val recordedSteps: MutableList<RecordedStep> = CopyOnWriteArrayList()

        fun clearSavedRecording(context: Context) {
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(KEY_FLOW).apply()
            recordedSteps.clear()
            instance?.recordedSteps?.clear()
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        serviceInfo = serviceInfo.apply {
            eventTypes = AccessibilityEvent.TYPE_VIEW_CLICKED or
                    AccessibilityEvent.TYPE_VIEW_LONG_CLICKED or
                    AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED or
                    AccessibilityEvent.TYPE_VIEW_SCROLLED or
                    AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED or
                    AccessibilityEvent.TYPE_WINDOWS_CHANGED or
                    AccessibilityEvent.TYPE_VIEW_SELECTED or
                    AccessibilityEvent.TYPE_VIEW_FOCUSED
            feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
            notificationTimeout = 80
            flags = flags or
                    AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS or
                    AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS or
                    AccessibilityServiceInfo.FLAG_INCLUDE_NOT_IMPORTANT_VIEWS
        }
        loadSavedRecording()
    }

    fun startNewRecording() {
        recordedSteps.clear()
        Companion.recordedSteps.clear()
        isRecording = true
        lastActionAt = SystemClock.elapsedRealtime()
        lastTextKey = ""
        lastTextAt = 0L
    }

    fun stopAndSaveRecording(): Int {
        isRecording = false
        saveRecording()
        return recordedSteps.size
    }

    fun launchTaobao() {
        val intent = packageManager.getLaunchIntentForPackage(TAOBAO_PACKAGE)
        if (intent != null) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
        } else {
            Toast.makeText(this, "未找到淘宝 App，请先安装淘宝。", Toast.LENGTH_LONG).show()
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || !isRecording || isReplaying) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg != TAOBAO_PACKAGE) return

        val source = event.source
        val node = source ?: findNodeForEvent(event)
        val meta = nodeMeta(node)
        val now = SystemClock.elapsedRealtime()
        val wait = normalizedWait(now - lastActionAt)

        when (event.eventType) {
            AccessibilityEvent.TYPE_VIEW_CLICKED -> {
                val point = nodeCenter(node)
                append(RecordedStep("CLICK", now, wait, pkg, meta.className, meta.viewId,
                    meta.text, meta.description, point?.first, point?.second, sensitive = meta.sensitive))
            }
            AccessibilityEvent.TYPE_VIEW_LONG_CLICKED -> {
                val point = nodeCenter(node)
                append(RecordedStep("LONG_CLICK", now, wait, pkg, meta.className, meta.viewId,
                    meta.text, meta.description, point?.first, point?.second, durationMs = 650,
                    sensitive = meta.sensitive))
            }
            AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED -> {
                val text = event.text?.joinToString("")?.takeIf { it.isNotEmpty() }
                if (text != null) {
                    val key = "${meta.viewId}|$text|$pkg"
                    if (key != lastTextKey || now - lastTextAt > 500) {
                        append(RecordedStep("INPUT", now, wait, pkg, meta.className, meta.viewId,
                            if (meta.sensitive) null else text, meta.description,
                            sensitive = meta.sensitive))
                        lastTextKey = key
                        lastTextAt = now
                    }
                }
            }
            AccessibilityEvent.TYPE_VIEW_SCROLLED -> {
                if (Build.VERSION.SDK_INT >= 28) {
                    val dx = event.scrollDeltaX
                    val dy = event.scrollDeltaY
                    if (dx != 0 || dy != 0) {
                        val point = nodeCenter(node)
                        append(RecordedStep("SCROLL", now, wait, pkg, meta.className, meta.viewId,
                            meta.text, meta.description, point?.first, point?.second,
                            scrollDx = dx, scrollDy = dy))
                    }
                }
            }
        }
    }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        if (isRecording && !isReplaying && event.action == KeyEvent.ACTION_UP &&
            (event.keyCode == KeyEvent.KEYCODE_BACK)) {
            val now = SystemClock.elapsedRealtime()
            append(RecordedStep("BACK", now, normalizedWait(now - lastActionAt),
                null, null, null, null, null))
        }
        return false
    }

    private fun append(step: RecordedStep) {
        // Collapse noisy duplicate accessibility events while retaining actual action order.
        if (recordedSteps.lastOrNull()?.let { it.type == step.type &&
                    it.packageName == step.packageName && it.viewId == step.viewId &&
                    it.text == step.text && step.timestamp - it.timestamp < 120 } == true) return
        recordedSteps.add(step)
        Companion.recordedSteps.clear()
        Companion.recordedSteps.addAll(recordedSteps)
        lastActionAt = step.timestamp
    }

    private fun normalizedWait(raw: Long): Long = raw.coerceIn(80L, 30_000L)

    private data class NodeMeta(
        val className: String?, val viewId: String?, val text: String?,
        val description: String?, val sensitive: Boolean
    )

    private fun nodeMeta(node: AccessibilityNodeInfo?): NodeMeta {
        if (node == null) return NodeMeta(null, null, null, null, false)
        val inputType = node.inputType
        val sensitive = (inputType and android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD) != 0 ||
                (inputType and android.text.InputType.TYPE_NUMBER_VARIATION_PASSWORD) != 0 ||
                (inputType and android.text.InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD) != 0
        return NodeMeta(
            node.className?.toString(), node.viewIdResourceName,
            node.text?.toString()?.takeIf { it.isNotBlank() },
            node.contentDescription?.toString()?.takeIf { it.isNotBlank() }, sensitive
        )
    }

    private fun nodeCenter(node: AccessibilityNodeInfo?): Pair<Float, Float>? {
        if (node == null) return null
        val r = Rect()
        node.getBoundsInScreen(r)
        if (r.width() <= 0 || r.height() <= 0) return null
        return Pair(r.exactCenterX(), r.exactCenterY())
    }

    private fun findNodeForEvent(event: AccessibilityEvent): AccessibilityNodeInfo? = event.source

    fun startReplay() {
        if (isReplaying) return
        if (recordedSteps.isEmpty()) loadSavedRecording()
        if (recordedSteps.isEmpty()) return
        isReplaying = true
        Thread {
            try {
                recordedSteps.toList().forEachIndexed { index, step ->
                    SystemClock.sleep(step.waitMs)
                    val ok = executeStep(step)
                    if (!ok) {
                        Toast.makeText(this, "第 ${index + 1} 步执行失败，已停止回放。", Toast.LENGTH_LONG).show()
                        return@Thread
                    }
                }
                Toast.makeText(this, "回放完成，共 ${recordedSteps.size} 步。", Toast.LENGTH_SHORT).show()
            } finally {
                isReplaying = false
            }
        }.start()
    }

    private fun executeStep(step: RecordedStep): Boolean {
        if (step.sensitive) {
            Toast.makeText(this, "敏感步骤已暂停，请手动完成后再继续操作。", Toast.LENGTH_LONG).show()
            return true
        }
        return when (step.type) {
            "CLICK" -> clickTarget(step, false)
            "LONG_CLICK" -> clickTarget(step, true)
            "INPUT" -> inputTarget(step)
            "SCROLL" -> scrollTarget(step)
            "BACK" -> performGlobalAction(GLOBAL_ACTION_BACK)
            else -> true
        }
    }

    private fun clickTarget(step: RecordedStep, long: Boolean): Boolean {
        val node = findBestNode(step)
        if (node != null) {
            val action = if (long) AccessibilityNodeInfo.ACTION_LONG_CLICK else AccessibilityNodeInfo.ACTION_CLICK
            if (node.isClickable || node.isLongClickable) {
                if (node.performAction(action)) return true
            }
        }
        val x = step.x ?: return false
        val y = step.y ?: return false
        return dispatchTap(x, y, if (long) 650L else TAP_DURATION)
    }

    private fun inputTarget(step: RecordedStep): Boolean {
        val node = findBestNode(step) ?: return false
        val text = step.text ?: return true
        val args = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text) }
        return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    private fun scrollTarget(step: RecordedStep): Boolean {
        val node = findBestNode(step)
        if (node != null) {
            val action = when {
                (step.scrollDy ?: 0) > 0 -> AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
                (step.scrollDy ?: 0) < 0 -> AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
                (step.scrollDx ?: 0) > 0 -> AccessibilityNodeInfo.ACTION_SCROLL_RIGHT
                else -> AccessibilityNodeInfo.ACTION_SCROLL_LEFT
            }
            if (node.performAction(action)) return true
        }
        val x = step.x ?: (step.x2 ?: 500f)
        val y = step.y ?: (step.y2 ?: 1000f)
        val dx = step.scrollDx ?: 0
        val dy = step.scrollDy ?: 600
        val endX = x + dx.coerceIn(-1000, 1000)
        val endY = y + (-dy).coerceIn(-1600, 1600)
        return dispatchSwipe(x, y, endX, endY, 450)
    }

    private fun findBestNode(step: RecordedStep): AccessibilityNodeInfo? {
        val root = rootInActiveWindow ?: return null
        val nodes = ArrayList<AccessibilityNodeInfo>()
        collectNodes(root, nodes)
        step.viewId?.let { id -> nodes.firstOrNull { it.viewIdResourceName == id }?.let { return it } }
        step.contentDescription?.takeIf { it.isNotBlank() }?.let { desc ->
            nodes.firstOrNull { it.contentDescription?.toString() == desc }?.let { return it }
        }
        step.text?.takeIf { it.isNotBlank() }?.let { text ->
            nodes.firstOrNull { it.text?.toString() == text }?.let { return it }
            nodes.firstOrNull { it.text?.toString()?.contains(text) == true }?.let { return it }
        }
        step.className?.let { cls ->
            nodes.firstOrNull { it.className?.toString() == cls }?.let { return it }
        }
        return null
    }

    private fun collectNodes(node: AccessibilityNodeInfo, out: MutableList<AccessibilityNodeInfo>) {
        out.add(node)
        for (i in 0 until node.childCount) node.getChild(i)?.let { collectNodes(it, out) }
    }

    private fun dispatchTap(x: Float, y: Float, duration: Long): Boolean {
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, duration.coerceAtLeast(1)))
            .build()
        return dispatchGesture(gesture, null, null)
    }

    private fun dispatchSwipe(x: Float, y: Float, x2: Float, y2: Float, duration: Long): Boolean {
        val path = Path().apply { moveTo(x, y); lineTo(x2, y2) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, duration))
            .build()
        return dispatchGesture(gesture, null, null)
    }

    private fun saveRecording() {
        val array = JSONArray()
        recordedSteps.forEach { array.put(it.toJson()) }
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_FLOW, array.toString()).apply()
    }

    private fun loadSavedRecording() {
        val raw = getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_FLOW, null) ?: return
        try {
            val array = JSONArray(raw)
            recordedSteps.clear()
            Companion.recordedSteps.clear()
            for (i in 0 until array.length()) recordedSteps.add(RecordedStep.fromJson(array.getJSONObject(i)))
            Companion.recordedSteps.addAll(recordedSteps)
        } catch (_: Exception) {
            recordedSteps.clear()
            Companion.recordedSteps.clear()
        }
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        if (instance === this) instance = null
        super.onDestroy()
    }
}
