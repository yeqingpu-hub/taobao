package com.example.taoautorecorder

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.Button
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var recordStatus: TextView
    private lateinit var log: TextView
    private val handler = Handler(Looper.getMainLooper())

    private val refreshTask = object : Runnable {
        override fun run() {
            val service = AutomationAccessibilityService.instance
            status.text = if (service != null) "无障碍服务：已连接" else "无障碍服务：未连接"
            recordStatus.text = when {
                service?.isRecording == true -> "当前状态：录制中（${service.recordedSteps.size} 步）"
                service?.isReplaying == true -> "当前状态：回放中"
                else -> "当前状态：待机（${AutomationAccessibilityService.recordedSteps.size} 步）"
            }
            handler.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        status = findViewById(R.id.status)
        recordStatus = findViewById(R.id.recordStatus)
        log = findViewById(R.id.log)

        findViewById<Button>(R.id.accessibility).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        findViewById<Button>(R.id.startRecord).setOnClickListener {
            val service = AutomationAccessibilityService.instance
            if (service == null) {
                log.text = "请先在系统设置中打开“淘宝操作助手”无障碍服务。"
                return@setOnClickListener
            }
            service.startNewRecording()
            log.text = "已开始录制。正在打开淘宝；打开后按正常方式操作即可。\n注意：支付、验证码、密码等敏感步骤不会自动保存密码内容。"
            service.launchTaobao()
        }

        findViewById<Button>(R.id.stopRecord).setOnClickListener {
            val service = AutomationAccessibilityService.instance
            if (service == null) {
                log.text = "无障碍服务未连接。"
                return@setOnClickListener
            }
            val count = service.stopAndSaveRecording()
            log.text = "录制结束并已保存，共 $count 步。下次可直接回放最近一次流程。"
        }

        findViewById<Button>(R.id.replay).setOnClickListener {
            val service = AutomationAccessibilityService.instance
            if (service == null) {
                log.text = "无障碍服务未连接。"
                return@setOnClickListener
            }
            if (AutomationAccessibilityService.recordedSteps.isEmpty()) {
                log.text = "没有可回放的流程。请先录制一次。"
                return@setOnClickListener
            }
            service.startReplay()
            log.text = "已开始回放。程序会优先按控件特征寻找目标，找不到时再使用录制坐标。"
        }

        findViewById<Button>(R.id.clear).setOnClickListener {
            AutomationAccessibilityService.clearSavedRecording(this)
            log.text = "已清空保存的流程。"
        }
    }

    override fun onResume() {
        super.onResume()
        handler.post(refreshTask)
    }

    override fun onPause() {
        handler.removeCallbacks(refreshTask)
        super.onPause()
    }
}
